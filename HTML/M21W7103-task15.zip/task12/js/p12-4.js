
		let cr=[];
		let id=null;
		const cv=document.querySelector("canvas");
		const gc=cv.getContext("2d");
		const btn=document.querySelector("#btn");

		btn.addEventListener("click",()=>{
			create();
            draw();
			if (id) {
				return;
			}	else{
				id = setInterval(draw,10);
			setInterval(()=> {
					gc.clearRect(1,0,cv.width,cv.height);
					cr.length = 0;
				},10000);
			}	
		})

		function create() {
			let distance = [1,-1]; //数组用于生成-1和1之间的随机数
			let c = {x:Math.random()*560+40,y:Math.random()*400+40,r:40, //为防止小球一出生就在边界，x轴坐标为40-600随机，y轴坐标为40-440随机
			         dx:distance[Math.round(Math.random())],
					 dy:distance[Math.round(Math.random())]}; //dx：定义小球初始横轴运动方向；dy：定义小球初始纵轴运动方向
			cr.push(c);
		}

		function draw(){
			gc.clearRect(0,0,cv.width,cv.height);
			for(let i=0;i<cr.length;i++){
				if (cr[i].x - cr[i].r < 0 || cr[i].x + cr[i].r > 640) { //若小球即将在x轴超出边界，移动换向
					cr[i].dx = 0 - cr[i].dx;
				}
				if (cr[i].y - cr[i].r < 0 || cr[i].y + cr[i].r > 480) {  //若小球即将在y轴超出边界，移动换向
					cr[i].dy = 0 - cr[i].dy;
				}
				cr[i].x = cr[i].x + cr[i].dx; //小球的横轴运动方向从数组中取
				cr[i].y = cr[i].y + cr[i].dy; //小球的纵轴运动方向从数组中取
				gc.beginPath();
		    	gc.lineWidth=5;
		    	gc.strokeStyle="blue";
	  	  		gc.arc(cr[i].x,cr[i].y,cr[i].r,0,2*Math.PI);
	  	  		gc.stroke();
		}
	}	
