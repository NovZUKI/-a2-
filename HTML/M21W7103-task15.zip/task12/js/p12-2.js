
		let c={x:0,y:0,r:50};
		let id=null;
		//canvasを得る
		const cv=document.querySelector("canvas");
		//描画コンテクスト取得
		const gc=cv.getContext("2d");
		const btn=document.querySelector("#btn");
		//イベントリスナーを定義
		btn.addEventListener("click",()=>{
			draw();
		})
		function draw(){
			c.x=parseInt(Math.random()*640);
			c.y=parseInt(Math.random()*480);
			gc.beginPath();
			gc.lineWidth=10;
			gc.strokeStyle="blue";
			gc.arc(c.x,c.y,c.r,0,2*Math.PI);
			gc.stroke();
		}
