
		let list = document.querySelectorAll(".list1"); 
		for(let i = 0;i<list.length;i++){
			list[i].addEventListener("mouseover",()=>{
			list[i].classList.add("anime1");
			})
			list[i].addEventListener("mouseout",()=>{
			list[i].classList.remove("anime1");
			})
		}