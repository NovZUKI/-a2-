
		let list = document.querySelectorAll(".list1"); 
		for(let i = 0;i<list.length;i++){
			list[i].addEventListener("click",()=>{
			list[i].classList.toggle("anime1");
			})
		}
		