
	let list = document.querySelectorAll("dt"); 
	let ddlist = document.querySelectorAll("dd"); 
		for(let i = 0;i<list.length;i++){
			list[i].addEventListener("click",()=>{
			ddlist[i].classList.toggle("anim");
			})
		}
		
