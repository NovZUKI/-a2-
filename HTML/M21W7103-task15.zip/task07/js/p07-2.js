
const btn1=document.querySelector("#btn1");
const btn2=document.querySelector("#btn2");
const btn3=document.querySelector("#btn3");


	let menu=['子羊の蒸し','熊の手の蒸し','鹿の尾の蒸し','花鴨の焼き','雛鶏の焼き'];
	let m_list=[];
	let menu_list=document.querySelector("#list");
	btn2.addEventListener("click",()=>{
		meal();
})
function meal(){
	let ran=parseInt(Math.random()*5);
	m_list.push(menu[ran]);
	menu_list.textContent=m_list.join(",");
}
btn3.addEventListener("click",()=>{
	cancel();
})
function cancel(){
	m_list.shift();
	menu_list.textContent=m_list.join(",");
}

btn1.addEventListener("click",()=>{
	s_meal();
})
function s_meal(){
	let ran=parseInt(Math.random()*5);
	m_list.unshift(menu[ran]);
	menu_list.textContent=m_list.join(",");
}