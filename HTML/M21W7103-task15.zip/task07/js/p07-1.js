const btn=document.querySelector("button");
btn.addEventListener("click",()=>{
	divination();
})
function divination(){
		let menulist=['大吉','中吉','吉','凶']
		let augury=document.querySelector("#output");
	  let number=parseInt(Math.random()*4);
		augury.textContent="あなたの運勢は"+menulist[number]+"です";
	}