
		let btnobj1=document.querySelector("#btn1");
		let btnobj2=document.querySelector("#btn2");
		let result=document.querySelector("#result");
		btnobj1.addEventListener("click",function(){
			let input=document.querySelector("#inp");
			result.textContent="円周:"+Number(input.value)*2*Math.PI;
		})
		btnobj2.addEventListener("click",function(){
			let input=document.querySelector("#inp");
			result.textContent="面積:"+Number(input.value)*Number(input.value)*Math.PI;
		})
	