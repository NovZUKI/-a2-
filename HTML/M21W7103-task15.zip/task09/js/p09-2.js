
		let num=document.querySelector("#inp");
		num.addEventListener("input",()=>{
			let result=document.querySelector("#result");
			result.textContent="面積:"+Number(num.value)*Number(num.value)*Math.PI;
		})