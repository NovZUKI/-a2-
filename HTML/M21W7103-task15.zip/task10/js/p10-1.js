
	// ==== それぞれのボタンを押した時のイベントリスナーを設定し処理を定義する ====
	//テキストボックス
	let tbox_btn=document.querySelector("#tbox_btn");
	tbox_btn.addEventListener("click",()=>{
		let input1=document.querySelector("#input1").value;
		let tbox_result=document.querySelector("#tbox_result");
		tbox_result.textContent=input1;
	})
	//スライダー
	let range_btn=document.querySelector("#range_btn");
	range_btn.addEventListener("click",()=>{
		let input2=document.querySelector("#input2").value;
		let range_result=document.querySelector("#range_result");
		range_result.textContent=input2;
	})

	//テキストエリア
	let tarea_btn=document.querySelector("#tarea_btn");
	tarea_btn.addEventListener("click",()=>{
		let input3=document.querySelector("#input3").value;
		let tarea_result=document.querySelector("#tarea_result");
		tarea_result.textContent=input3;
	})

	//ラジオボタン
	let rbtn_btn = document.querySelector("#rbtn_btn");
	rbtn_btn.addEventListener("click",()=>{
			let result="";
			let input4 =document.querySelectorAll("#input4 input");
 			for (let i=0; i<input4.length;i++){
 				if (input4[i].checked){
 				result = input4[i].value;
 				}
			}
			let rbtn_result=document.querySelector("#rbtn_result");
			rbtn_result.textContent=result;
		})


	//チェックボックス
	let cbox_btn = document.querySelector("#cbox_btn");
	cbox_btn.addEventListener("click",()=>{
			let result=[];
			let ops=document.querySelectorAll("#input5 input") ;
			for(let j=0;j<ops.length;j++){
				if(ops[j].checked){
					result.push(ops[j].value);
				}
			}
			let cbox_result=document.querySelector("#cbox_result");
			cbox_result.textContent=result;
		})


	//メニュー（単一）
	let select1_btn = document.querySelector("#select1_btn");
	select1_btn.addEventListener("click",()=>{
			let result=document.querySelector("#input6").value;
			let select1_result=document.querySelector("#select1_result");
			select1_result.textContent=result;

		})


	//メニュー（複数）
	let selectm_btn = document.querySelector("#selectm_btn");
	selectm_btn.addEventListener("click",()=>{
			let result=[];
			let ops=document.querySelector("#input7").options;
			for(k=0;k<ops.length;k++){
				if(ops[k].selected){
					result.push(ops[k].value);
				}
			}
			let selectm_result=document.querySelector("#selectm_result");
			selectm_result.textContent=result;

		})