	input1.addEventListener("input", function () {
		inp(input1,tbox_result);
	})
	input2.addEventListener("input", function () {
		inp(input2,range_result);
	})
	input3.addEventListener("input", function () {
		inp(input3,tarea_result);
	})
	input6.addEventListener("input", function () {
		inp(input6,select1_result);
	})
	function inp(input,result){
			result.textContent=input.value;
	}
	

	input4.addEventListener("change", function () {
		qsa("#input4 input",rbtn_result);
	})
	input5.addEventListener("change", function () {
		qsa("#input5 input",cbox_result);
	})
	function qsa(input,result){
		let res=[];
		let ops=document.querySelectorAll(input) ;
		for(let j=0;j<ops.length;j++){
				if(ops[j].checked){
					res.push(ops[j].value);
				}
			}
			result.textContent=res;
	}


	input7.addEventListener("change", function () {
		qso(input7,selectm_result);
	})
	function qso(input,result){
		let res=[];
			let ops=input.options;
			for(k=0;k<ops.length;k++){
				if(ops[k].selected){
					res.push(ops[k].value);
				}
			}
			result.textContent=res;
	}