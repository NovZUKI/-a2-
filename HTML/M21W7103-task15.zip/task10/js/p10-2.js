	// ==== それぞれのボタンを押した時のイベントリスナーを設定し処理を定義する ====
	//テキストボックス
	let input1=document.querySelector("#input1");
	input1.addEventListener("input",()=>{
		let tbox_result=document.querySelector("#tbox_result");
		tbox_result.textContent=input1.value;
	})

	//スライダー
	let input2=document.querySelector("#input2");
	input2.addEventListener("input",()=>{
		let range_result=document.querySelector("#range_result");
		range_result.textContent=input2.value;
	})


	//テキストエリア
	let input3=document.querySelector("#input3");
	input3.addEventListener("input",()=>{
		let tarea_result=document.querySelector("#tarea_result");
		tarea_result.textContent=input3.value;
	})


	//ラジオボタン
	
	input4.addEventListener("change",()=>{
			let result="";
			let input4 =document.querySelectorAll("#input4 input");
 			for (let i=0; i<input4.length;i++){
 				if (input4[i].checked){
 				result = input4[i].value;
 				}
			}
			let rbtn_result=document.querySelector("#rbtn_result");
			rbtn_result.textContent=result;
		})


	//チェックボックス
	input5.addEventListener("change",()=>{
			let result=[];
			let ops=document.querySelectorAll("#input5 input") ;
			for(let j=0;j<ops.length;j++){
				if(ops[j].checked){
					result.push(ops[j].value);
				}
			}
			let cbox_result=document.querySelector("#cbox_result");
			cbox_result.textContent=result;
		})


	//メニュー（単一）
	input6.addEventListener("change",()=>{
			let result=document.querySelector("#input6").value;
			let select1_result=document.querySelector("#select1_result");
			select1_result.textContent=result;

		})

	//メニュー（複数）
	input7.addEventListener("change",()=>{
			let result=[];
			let ops=document.querySelector("#input7").options;
			for(k=0;k<ops.length;k++){
				if(ops[k].selected){
					result.push(ops[k].value);
				}
			}
			let selectm_result=document.querySelector("#selectm_result");
			selectm_result.textContent=result;

		})
