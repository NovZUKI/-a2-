const btn=document.querySelector("button");
btn.addEventListener("click",()=>{
	sumnum();
})
		function sumnum(){
			let m=parseInt(document.querySelector("#m_num").value);
			let n=parseInt(document.querySelector("#n_num").value);
			let out=document.querySelector("#output");
			let sum=0;
			for(let i=0;i<=(n-m);i++){
				sum=sum+m+i;
			}
			out.textContent=sum;
			
		}