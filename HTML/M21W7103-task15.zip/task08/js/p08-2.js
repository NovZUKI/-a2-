const btn=document.querySelector("button");
btn.addEventListener("click",()=>{
	minnum();
})


		function minnum(){
			let strings=document.querySelector("#numbers").value;
			let numbers=strings.split(",");
			let min=document.querySelector("#min");
			if(numbers.length!=0){
				min_number=parseInt(numbers[0]);
				for(var i=0;i<numbers.length;i++){
					let n=parseInt(numbers[i]);
					if(min_number>n){
						min_number=n;}
				}
				min.textContent=min_number;
			}
			else
				min.textContent="error";
		}